# rotazioni volley
rappresentazione via web degli schemi di ricezione a 3 nella pallavolo rispetto alla posizione del palleggiatore

Questa applicazione web è la traduzione in italiano del progetto [VBRotations](https://github.com/monkeysppp/VBRotations) di [Andy Edwards](https://github.com/monkeysppp)

l'applicazione può essere usata a questo indirizzo [https://napo.github.io/rotazionivolley/](https://napo.github.io/rotazionivolley/)




![](https://raw.githubusercontent.com/napo/rotazionivolley/master/demo/rotazionivolley.gif)
